package com.example.geoquest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StartGameLeaderboards extends AppCompatActivity {
    private Button startgame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_game_leaderboards);

        startgame = (Button) findViewById(R.id.startgame);
        startgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGamemodes();
            }
        });
    }

    public void openGamemodes() {
        Intent intent = new Intent(StartGameLeaderboards.this,Gamemodes.class);
        startActivity(intent);
    }
}