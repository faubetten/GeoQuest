package com.example.teste.controllers;

import com.example.teste.models.Foto;
import com.example.teste.models.User;
import com.example.teste.models.repository.FotoRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/foto")
@AllArgsConstructor
public class FotoController {
    final FotoRepository fotoRepository;

    @GetMapping("/all")
    public Iterable<Foto> getAll() {
        return fotoRepository.findAll();
    }

    @DeleteMapping("/all")
    public void deleteAll() {
        fotoRepository.deleteAll();
    }

    @PostMapping
    public Foto createUser(@RequestBody Foto foto) {
        fotoRepository.save(foto);
        return foto;
    }

    @DeleteMapping
    public void deleteUserByImage(@RequestParam String image) {
        fotoRepository.delete(fotoRepository.findByImagem(image));
    }
}
