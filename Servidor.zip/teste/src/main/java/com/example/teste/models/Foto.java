package com.example.teste.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "fotos")
public class Foto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "fotos_id", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "imagem", nullable = false, length = Integer.MAX_VALUE)
    private String imagem;

    @OneToMany(mappedBy = "locaisFotosFoto")
    private Set<LocaisFoto> locaisFotos = new LinkedHashSet<>();
}