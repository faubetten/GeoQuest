package com.example.teste.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "locais")
public class Locais {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "locais_id", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "coordenadas", nullable = false, length = Integer.MAX_VALUE)
    private String coordenadas;

    @NotNull
    @Column(name = "nome", nullable = false, length = Integer.MAX_VALUE)
    private String nome;

    @NotNull
    @Column(name = "morada", nullable = false, length = Integer.MAX_VALUE)
    private String morada;

    @OneToMany(mappedBy = "questLocaisLocais")
    private Set<QuestLocais> questLocais = new LinkedHashSet<>();

    @OneToMany(mappedBy = "locaisFotosLocais")
    private Set<LocaisFoto> locaisFotos = new LinkedHashSet<>();
}