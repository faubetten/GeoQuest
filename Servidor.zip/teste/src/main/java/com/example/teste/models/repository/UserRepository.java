package com.example.teste.models.repository;

import com.example.teste.models.User;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Long> {
    User findUserByUsersName(String username);
}
